userAge = input("Enter your age: ")
userAge = int(userAge) + 22
print("Now showing the shop items filtered by age ", userAge)